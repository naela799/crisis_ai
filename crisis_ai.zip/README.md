# Crisis Management AI Telegram Bot

This project combines a Telegram bot with a RAG system using NVIDIA Embeddings for crisis response.
