# Handles embedding, FAISS indexing, and retrieval
