# Load and preprocess emergency documents
